#include <iostream>
#include "invoice.h"


using namespace std;


    int main() {
        string number,desc;
        int quant;
        double valor;
        cout<<"Digita o número: "<<endl;
        cin>>number;
        cout<<"Digita a descrição do produto: "<<endl;
        cin>>desc;
        cout<<"Quantidade do produto do pedido:"<<endl;
        cin>>quant;
        cout<<"Valor por um item"<<endl;
        cin>>valor;
        Invoice::Invoice(quant,valor);
        Invoice *inv;
        inv = new Invoice(quant, valor);
        inv->setnum(number);
        inv->setdesc(desc);
        cout<<"Número: "+inv->getnum()<<endl;
        cout<<"\nDescrição: "<<inv->getdesc()<<endl;
        cout<<"\nQuantidade: "<<inv->getquant()<<endl;
        cout<<"\nValor: "<<inv->getpreco();
        cout<<""<<endl;
        cout<<"O Valor total é "<<inv->GetInvoiceAmount(quant,valor);
    }
