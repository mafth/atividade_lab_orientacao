using namespace std;

class Invoice{
    string num;
    string desc;
    int quant;
    int preco;
public:Invoice(int iniciaQuant ,double valor) {
        if (iniciaQuant > 0) {
            quant = iniciaQuant;
        } else {
            quant = 0;
        }
        if (valor > 0.0) {
            preco = valor;
        } else {
            preco = 0.0;
        }
    }
    string getnum(){
        return num;

    }
    string getdesc(){
        return desc;
    }
    int getquant(){
        return quant;

    }
    int getpreco(){
        return preco;

    }
    void setnum(string num){
        this->num=num;

    }
    void setdesc(string desc){
        this->desc=desc;
    }
    void setquant(int quant){
        this->quant=quant;
    }
    void setpreco(int preco){
        this->preco=preco;
    }
     double GetInvoiceAmount(int preco,int quant){
        double total = quant * preco;
         if(0<quant){
             this->quant=0;
         }

         if(0<preco){
             this->preco=0;
         }
        return total;
    }

};
