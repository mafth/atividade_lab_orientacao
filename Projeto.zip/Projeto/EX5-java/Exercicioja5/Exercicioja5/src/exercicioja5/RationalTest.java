/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioja5;

/**
 *
 * @author deiar
 */
public class RationalTest {
   
        public static void main(String[] args)
        {
                Rational r = new Rational(10,5);
                r.print(0);
                System.out.println(6/12);
        }

    
}
