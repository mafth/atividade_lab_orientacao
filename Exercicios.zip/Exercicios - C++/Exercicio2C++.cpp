/*


Caio Rios Sousa - CC3642 - 09/03/2018
Esse programa tem como prop�sito de por meio de classes,construtores e m�todos ,
armazenar o dia ,m�s e ano.No final do programa ele exibe as informa��es no formato 
DD/MM/AA


*/

#include <iostream>
#include <string>

using namespace std;

class Date{//Cria��o da classe data
	
public:
	
	Date(int dia,int mes,int ano){
		//Construtor
		setDia(dia);
		setMes(mes);
		setAno(ano);
		
	}
	//m�todo para atribuir Mes ao objeto
	void setMes(int mes_data){
		mes = mes_data;
	}
	//m�todo para atribuir Dia ao objeto
	void setDia(int dia_data){
		dia = dia_data;
	}
	//m�todo para atribuir Ano ao objeto
	void setAno(int ano_data){
		ano = ano_data;
	}
	//m�todo para obter o Mes do objeto
	int getMes(){
		return mes;
	}
	//m�todo para obter o Dia do objeto
	int getDia(){
		return dia;
	}
	//m�todo para obter o Ano do objeto
	int getAno(){
		return ano;
	}
	
	void imprimir(){
		//m�todo para imprimir Dia,M�s e Ano no formato DD/MM/AA
		 cout<<getDia()<<"/"<<getMes()<<"/"<<getAno()<<endl;
	
}
//Variaveis privadas
private:
    int mes,dia,ano;

};
	

int main(int argc ,char ** argv){
	int mes,dia,ano;
	

	cout<<"Digite o dia:";
	cin>>dia;
	cout<<"Digite o mes:";
	cin>>mes;
	cout<<"Digite o ano:";
	cin>>ano;	
	Date *data = new Date (dia,mes,ano);//Instanciando o objeto
	data->imprimir();//Usar a fun��o com as variaveis do objeto data
	

	

	
	return 0;
}





