/*


Caio Rios Sousa - CC3642 - 09/03/2018
Esse programa tem como prop�sito de por meio de classes,construtores e m�todos ,
armazenar o nome,sobrenome e sal�rio de 2 funcionarios e mostrar na tela,ap�s isso
o programa ir� calcular 10% do salario de cada funcion�rio e exibir na tela todas
informa��es novamente.


*/

#include <iostream> 
#include <cstdio>
#include <string> 

using namespace std; 

class Empregado { //declara��o da classe Empregado
	//atributos privados
	private:
		string nome;
		string sobrenome;
		double salario;
	//m�todos p�blicos
	public:
		//construtor da classe
		Empregado() {
			//atribui valores iniciais
			setNome("");
			setSobrenome("");
			setSalario(0.0);
		}
	
		//m�todo para atribuir nome ao objeto
		void setNome(string valor) {
			//atribui o parametro ao atributo do objeto
			nome = valor;
		}
	
		//m�todo para obter o nome do objeto
		string getNome(void) {
			return nome;
		}
	
		//m�todo para atribuir o sobrenome ao objeto
		void setSobrenome(string valor) {
			sobrenome = valor;
		}
	
		//m�todo para obter o sobrenome do objeto
		string getSobrenome(void) {
			return sobrenome;
		}
	
		//m�todo para atribuir o sal�rio ao objeto
		void setSalario(double valor) {
			if(valor < 0) {//verifica se o valor � negativo
				setSalario(0.0);//atribui valor 0.0 como valor padr�o
			} else {
				//atribui o parametro ao atributo
				salario = valor;
			}
		}
		//m�todo para obter o sal�rio do objeto
		double getSalario(void) {
			return salario;
		}
};

int main() {
	//declara��o de vari�veis
	Empregado func1, func2; //instancias da classe Empregado
	string nome;
	string sobrenome;
	double salario;
	
	//solicita o nome do Empregado func1
	cout << "Digite o nome do primeiro Empregado: ";
	cin >> nome;
	func1.setNome(nome);//atribui o nome ao func1
	//solicita o sobrenome de func1
	cout << "Digite o sobrenome do primeiro Empregado: ";
	cin >> sobrenome;
	func1.setSobrenome(sobrenome); //atribui o sobrenome ao func1
	//solicita o sal�rio de func1
	cout << "Digite o sal�rio do primeiro Empregado: ";
	cin >> salario;
	func1.setSalario(salario); //atribui o salario ao func1
	//solicita o nome do Empregado func2
	cout << "Digite o nome do segundo Empregado: ";
	cin >> nome;
	func2.setNome(nome); //atribui o nome ao func2
	//solicita o sobrenome de func2
	cout << "Digite o sobrenome do segundo Empregado: ";
	cin >> sobrenome;
	func2.setSobrenome(sobrenome); //atribui o sobrenome ao func2
	//solicita o sal�rio de func2
	cout << "Digite o sal�rio do segundo Empregado: ";
	cin >> salario;
	func2.setSalario(salario);//atribui o salario ao func2
	//exibe as informa��es de func1 e func2

	cout<<endl;
	cout << "Informacoes do primeiro Empregado:" << endl; //Impress�o na tela do funcionario 1 sem o aumento
	cout << "Nome: " << func1.getNome() << endl;
	cout << "Sobrenome: " << func1.getSobrenome() << endl;
	cout << "Salario: " << func1.getSalario() << endl << endl;
	
	cout<<endl;
	cout << "Informacoes do segundo Empregado:" << endl;//Impress�o na tela do funcionario 2 sem o aumento
	cout << "Nome: " << func2.getNome() << endl;
	cout << "Sobrenome: " << func2.getSobrenome() << endl;
	cout << "Salario: " << func2.getSalario() << endl;
	
	cout<<endl;
	cout<<"Salario apos aumento de 10%"<<endl;
	
	cout<<endl;
	cout << "Informacoes do primeiro Empregado:" << endl;//Impress�o na tela do funcionario 1 com o aumento
	cout << "Nome: " << func1.getNome() << endl;
	cout << "Sobrenome: " << func1.getSobrenome() << endl;
	cout << "Salario: " << func1.getSalario()*1.1 << endl << endl;

	cout<<endl;
	cout << "Informacoes do segundo Empregado:" << endl;//Impress�o na tela do funcionario 2 com o aumento
	cout << "Nome: " << func2.getNome() << endl;
	cout << "Sobrenome: " << func2.getSobrenome() << endl;
	cout << "Salario: " << func2.getSalario()*1.1 << endl;
	
	
	return 0;
}
