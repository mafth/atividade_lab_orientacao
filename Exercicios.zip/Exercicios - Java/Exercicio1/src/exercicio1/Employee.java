/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;
import java.util.scanner;
/**
 *
 * @author deiar
 */
public class Employee {

    String nome;
    String sobrenome;
    double salario;
    
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
 
    
    public void setNome(String strNome){
        nome = strNome;
    
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public double getSalario() {
        return salario;
    }
    
    public void setsalario(double novoSalario){
        if (novoSalario < 0){
            salario = 0;
        }
        else{
            novoSalario = salario;
        }
                    
        }
    
        public void imprime(){
        System.out.println("Nome: " + getNome());
        System.out.println("Sobrenome:" + getSobrenome());
        System.out.println("Salario:" + getSalario());
        }    
    }



