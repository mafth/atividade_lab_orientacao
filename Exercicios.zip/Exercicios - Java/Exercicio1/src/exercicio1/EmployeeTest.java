/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;
import java.util.Scanner;
import java.util.Set;
/**
 *
 * @author deiar
 */
public class EmployeeTest {
    
    


    public static void main(String[] args) {
        // TODO code application logic here
        
        Employee f = new Employee();
        f.setNome("Matheus");
        f.setSalario(5000);
        f.setSobrenome("Ferreira");
        
       
        
        Employee g = new Employee();
        g.setNome("Alan");
        g.setSalario(5000);
        g.setSobrenome("Soares");
        
        f.imprime();
        g.imprime();
     
      
        f.setSalario(f.getSalario()*1.1);
        g.setSalario(g.getSalario()*1.1);
    
        
        f.imprime();
        g.imprime();
    }
    


    
}
