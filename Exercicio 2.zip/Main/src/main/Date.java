package main;

public class Date {
	
		private int month;
		private int day;
		private int year;

		Date(int theMonth,int theDay , int theYear){
			month=checkMonth(theMonth);
			day=checkDay(theDay);
			year=theYear;
			
		}
		 public void  nextDay(){
		   day = day +1;
      if(checkDay(day)==1 && day > 1){
        day = 1;
        month=month+1;
        if(checkMonth(month)==1){
          month =1;
          year=year +1;
        } 
      }
		}
  	
		private int checkMonth(int testMonth) {
			if(testMonth>0 && testMonth<=12)
				return testMonth;
			else{
				System.out.printf("Invalid Month (%d) set to 1",testMonth );
				return 1;
			}
			
		}

		private int checkDay(int testDay) {
			int daysperMonth[]=
				{0,31,28,31,30,31,30,31,31,30,31,30,31};
			
			if(testDay>0 && testDay <=daysperMonth[month])
				return testDay;
			
			if(month==2&&testDay==29 &&(year%400==0||(year%4==0 && year%100!=0)))
				return testDay;
			
			System.out.printf("Invalid day (%d) set to 1", testDay);
			return 1;
		}
			
			public String toString()
		{
			return String.format("%d/%d/%d", month, day, year );
		}
		
		
}