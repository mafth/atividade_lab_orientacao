/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.Scanner;

public class Main{
 
	public static void main(String[] args){
		Scanner entrada = new Scanner(System.in); 
		
		
		
		int d = entrada.nextInt();
		int m = entrada.nextInt();
		int a= entrada.nextInt();
		
		Date data = new Date( m,d,a);
		
		for(int i=0;i<20;i++){
		  data.nextDay();
		  System.out.println(data);
		}
	}
	
		
		
	}
