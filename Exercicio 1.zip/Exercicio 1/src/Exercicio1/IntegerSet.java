package Exercicio1;

import java.util.Arrays;
/*
 Cada objeto IntegerSet pode 
 armazenar inteiros no intervalo de 0 a 100. O conjunto é 
 representado por um array de booleans. O elemento do 
 array a[i] é true se o inteiro i estiver no conjunto. O 
 elemento do array a[j] é false se o inteiro j não 
 estiver no conjunto.   
 */
/**
 * @author 
 *
 */
public class IntegerSet {
    private static final int MAX = 100;
    private boolean[] a; // [0...100]
    /**
     O construtor sem argumento 
     inicializa o array java como conjunto vazio (isto é, um 
     conjunto cuja representação de array contém todos os 
     valores false).
     */
    public IntegerSet() {
        a = new boolean[MAX + 1];
    }
    /**
     O método 
     union, que cria um terceiro conjunto com a união teórica 
     de dois conjuntos existentes
     * @param c1
     * @param c2
     * @return
     */
    public static IntegerSet union(IntegerSet c1, IntegerSet c2) {
        IntegerSet r = new IntegerSet();
        for (int i = 0; i <= MAX; ++i) {
            r.a[i] = c1.a[i] | c2.a[i];
        }
        return r;
    }
    /**
     o método intersection, que 
     cria um terceiro conjunto com a intersecção teórica de 
     dois conjuntos existentes;   
     * @param c1
     * @param c2
     * @return
     */
    public static IntegerSet intersection(IntegerSet c1, IntegerSet c2) {
        IntegerSet r = new IntegerSet();
        for (int i = 0; i <= MAX; ++i) {
            r.a[i] = c1.a[i] & c2.a[i];
        }
        return r;
    }
    /**
     o método insertElement que 
     insere um novo elemento num conjunto;
     * @param i
     */
    public void insertElement(int i) {
        a[i] = true;
    }
    /**
     o método 
     deleteElement que exclui um elemento de um conjunto;
     * @param i
     */
    public void deleteElement(int i) {
        a[i] = false;
    }
    /**
     e o método toSetString que retorna uma string 
     contendo os elementos do conjunto, ou um - caso a 
     posição daquele elemento seja false.
     * @return
     */
    public String toSetString() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i <= MAX; ++i) {
            if (a[i])
                sb.append(i).append(",");
            else
                sb.append("-").append(",");
        }
        return sb.toString();
    }
    /**
     o 
     método isEqualTo que determina se dois conjuntos são 
     iguais,   
     * @param c1
     * @param c2
     * @return
     */
    public static boolean isEqualTo(IntegerSet c1, IntegerSet c2) {
        return Arrays.equals(c1.a, c2.a);
    }
}